<?php

    session_start();
if(isset($_POST['naslov_vijesti']))
{
    $kategorija = $_POST ['kategorija'];
    $naslov_vijesti = $_POST['naslov_vijesti'];
    $slika = $_FILES['slika']['name'];
    $kratki_sadrzaj = $_POST['kratki_sadrzaj'];
    $sadrzaj = $_POST['sadrzaj_vijesti'];
    $autor = $_COOKIE['username'];
}
   
?>

<!DOCTYPE html>
<html>
<head>
    <title>BMK</title>
    <meta charset="UTF-8"/>
    <meta name="author" content="Matija Đurekovec"/>
    <meta http-equiv="content-language" content="hr"/>
    <link rel="stylesheet" type="text/css" href="style.css"/>
    <link rel="icon" href="img/bmk-logo-fav.png" type="image/x-icon">
</head>
<body>
    <header>
        <div id="center">
            <nav>
                <ul>
                    <li><a href="index.php"><img src="img/bmk-logo.png"></a></li>
                    <li class="lista_polozaj"><a href="index.php">Početna</a></li>
                    <li class="lista_polozaj"><a href="vijesti.php">Vijesti</a></li>
                    <li class="lista_polozaj"><a href="unos.php">Unos vijesti</a></li>
                    <li class="lista_polozaj"><a href="administracija.php">Pregled vijesti</a></li>
                    <li class="lista_polozaj"><a href="about.php">O nama</a></li>
                </ul>
                <ul id="prijava_registracija">
                    <?php
                        if (isset($_COOKIE['username']))
                        {
                            echo '
                                <li><a href="">' .$_COOKIE['username']. '</a></li>
                                <li><a href="logout.php">Odjava</a></li>
                            ';
                        }
                        else
                        {
                            echo '
                                <li><a href="login.php">Prijava</a></li>
                                <li><a href="register.php">Registracija</a></li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <main id="skripta">
            <h2>
                <?php
                  if (strtoupper($kategorija) == 'GAMING')
                  {
                     echo '<img class="blue-bar" src="img/blue-bar.png">';
                  }
                  else if (strtoupper($kategorija) == 'E-SPORTS')
                  {
                     echo '<img class="green-bar" src="img/green-bar.png">';
                  }
                  else if (strtoupper($kategorija) == 'TEHNOLOGIJA')
                  {
                     echo '<img class="yellow-bar" src="img/yellow-bar.png">';
                  }
                  else
                  {
                     echo '<img class="red-bar" src="img/red-bar.png">';
                  }
                    echo strtoupper($kategorija);
                ?>
            </h2>
            <h3>
                <?php
                    echo $naslov_vijesti;
                ?>
            </h3>
            <p><b>AUTOR:</b>
                <?php
                    echo $autor;
                ?>
            </p>
            <p><b>OBJAVLJENO:</b>
                <?php
                    $vrijeme_objave = date('d-m-Y H:i:s');
                    echo $vrijeme_objave;
                ?>
            </p>
            <?php
                echo '<img class="glavna-slika" src="img/' .$slika. '">';
            ?>
            <p><b>
                <?php
                    echo $kratki_sadrzaj;
                ?>
            </p></b>
            <p>
                <?php
                    echo $sadrzaj;
                ?>
            </p>
    </main>
    <footer>
        <div id="center">
            <p>Stranicu napravio: Matija Đurekovec</p>
            <p>E-mail: mdurekove@tvz.hr</p>
            <b><p>Copyright © 2021 BMK.</p></b>
        </div>
    </footer>
</body>
</html>

<?php

include 'XML_baza_load.php';

if(isset($_POST['naslov_vijesti']))
{
    if (isset($_POST['arhiva']))
    {
        $arhiva = 'Y';
    }
    else {
        $arhiva = 'N';
    }
    foreach ($vijestiXML as $broj)
    {
        $id = $broj->id; 
    }

    $id = $id + 1;

    // UNOS ZA XML BAZU //

    $XML_root = 'Vijesti';

    $unos = new DOMDocument ('1.0' , 'UTF-8');
    $unos->preserveWhiteSpace = true;
    $unos->standalone = true;
    $unos->formatOutput = true;
    $unos->recover = true;
    $unos->strictErrorChecking = true;

    // PROVJERA DA LI POSTOJI DATOTEKA //

    if (realpath ('vijesti.xml'))
    {
        $unos->load('vijesti.xml');
        $root = $unos->getElementsByTagName($XML_root)->item(0);
    }

    // KREIRANJE ELEMENATA //

    $unos_vijesti = $unos->createElement($kategorija);
    $root->appendChild($unos_vijesti);

    $unos_vijesti_id = $unos->createElement('id',$id);
    $unos_vijesti->appendChild($unos_vijesti_id);

    $unos_vijesti_autor_username = $unos->createElement('autor_username',$autor);
    $unos_vijesti->appendChild($unos_vijesti_autor_username);

    $unos_vijesti_naslov = $unos->createElement('naslov',$naslov_vijesti);
    $unos_vijesti->appendChild($unos_vijesti_naslov);

    $unos_vijesti_kratki_sadrzaj = $unos->createElement('kratki_sadrzaj',$kratki_sadrzaj);
    $unos_vijesti->appendChild($unos_vijesti_kratki_sadrzaj);

    $unos_vijesti_sadrzaj = $unos->createElement('sadrzaj',$sadrzaj);
    $unos_vijesti->appendChild($unos_vijesti_sadrzaj);

    $unos_vijesti_slika = $unos->createElement('slika',$slika);
    $unos_vijesti->appendChild($unos_vijesti_slika);

    $unos_vijesti_arhiva = $unos->createElement('arhiva',$arhiva);
    $unos_vijesti->appendChild($unos_vijesti_arhiva);

    $unos_vijesti_vrijeme = $unos->createElement('vrijeme',$vrijeme_objave);
    $unos_vijesti->appendChild($unos_vijesti_vrijeme);

    $unos_vijesti_kategorija = $unos->createElement('kategorija',$kategorija);
    $unos_vijesti->appendChild($unos_vijesti_kategorija);

    // AŽURIRANJE NOVOG DOKUMENTA //

    $unos->save('vijesti.xml');

}


?>