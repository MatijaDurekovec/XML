<?php

    include 'XML_baza_load.php';
    session_start();   

?>

<!DOCTYPE html>
<html>
<head>
    <title>BMK</title>
    <meta charset="UTF-8"/>
    <meta name="author" content="Matija Đurekovec"/>
    <meta http-equiv="content-language" content="hr"/>
    <link rel="stylesheet" type="text/css" href="style.css"/>
    <link rel="icon" href="img/bmk-logo-fav.png" type="image/x-icon">
</head>
<body>
    <header>
        <div id="center">
            <nav>
                <ul>
                    <li><a href="index.php"><img src="img/bmk-logo.png"></a></li>
                    <li class="lista_polozaj"><a href="index.php">Početna</a></li>
                    <li class="lista_polozaj"><a href="vijesti.php">Vijesti</a></li>
                    <li class="lista_polozaj"><a href="unos.php">Unos vijesti</a></li>
                    <li class="lista_polozaj"><a href="administracija.php">Pregled vijesti</a></li>
                    <li class="lista_polozaj"><a href="about.php">O nama</a></li>
                </ul>
                <ul id="prijava_registracija">
                    <?php
                        if (isset($_COOKIE['username']))
                        {
                            echo '
                                <li><a href="">' .$_COOKIE['username']. '</a></li>
                                <li><a href="logout.php">Odjava</a></li>
                            ';
                        }
                        else
                        {
                            echo '
                                <li><a href="login.php">Prijava</a></li>
                                <li><a href="register.php">Registracija</a></li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <main>
        <div id="center">
            <?php
                if (isset($_COOKIE['username']))
                {
                    foreach ($vijestiXML as $autor_provjera)
                    {
                        if($_COOKIE['username'] == $autor_provjera->autor_username)
                        {
                            echo '
                                <form enctype="multipart/form-data" method="POST" action="">
                                    <label for="naslov">Naslov vijesti</label><br>
                                    <input type="text" name="naslov_vijesti" value="' .$autor_provjera->naslov. '"><br><br>
                                    <label for="kratki_sadrzaj">Kratki sadržaj vijesti (do 190 znakova)</label><br>
                                    <textarea cols="50" rows="12" name="kratki_sadrzaj" maxlength="190">' .$autor_provjera->kratki_sadrzaj. '</textarea><br><br>
                                    <label for="sadrzaj_vijesti">Sadržaj vijesti</label><br>
                                    <textarea cols="50" rows="12" name="sadrzaj_vijesti">' .$autor_provjera->sadrzaj. '</textarea><br><br>
                                    <label for="slika" class="slika">Slika:</label><br>
                                    <input type="file" accept="image/*" name="slika" value="' .$autor_provjera->slika. '"><br>
                                    <img src="img/' .$autor_provjera->slika. '" width=100px><br><br>
                                    <label for="kategorija">Kategorija vijesti:</label><br>
                                    <select name="kategorija" class="kategorija">';
                                    if ($autor_provjera->kategorija == 'E-sports')
                                    {
                                        echo '
                                            <option value="E-sports" selected>E-sports</option>
                                            <option value="Gaming">Gaming</option>
                                            <option value="Tehnologija">Tehnologija</option>
                                            <option value="YouTube">YouTube</option>
                                        ';
                                    }
                                    else if ($autor_provjera->kategorija == 'Gaming')
                                    {
                                        echo '
                                            <option value="E-sports">E-sports</option>
                                            <option value="Gaming" selected>Gaming</option>
                                            <option value="Tehnologija">Tehnologija</option>
                                            <option value="YouTube">YouTube</option>
                                        ';
                                    }
                                    else if ($autor_provjera->kategorija == 'Tehnologija')
                                    {
                                        echo '
                                            <option value="E-sports">E-sports</option>
                                            <option value="Gaming">Gaming</option>
                                            <option value="Tehnologija" selected>Tehnologija</option>
                                            <option value="YouTube">YouTube</option>
                                        ';
                                    }
                                    else
                                    {
                                        echo '
                                            <option value="E-sports">E-sports</option>
                                            <option value="Gaming">Gaming</option>
                                            <option value="Tehnologija">Tehnologija</option>
                                            <option value="YouTube" selected>YouTube</option>
                                        ';
                                    }
                            echo '    
                                    </select><br><br>
                                    <label for="spremiti">Spremiti u arhivu:</label><br>';
                                    if ($autor_provjera->arhiva == 'N')
                                    {
                                        echo '<input type="checkbox" name="arhiva" id="arhiva"><br><br>';
                                    }
                                    else 
                                    {
                                        echo '<input type="checkbox" name="arhiva" id="arhiva" checked><br><br>';
                                    }
                            echo '
                                    <input type="hidden" name="id" value="' .$autor_provjera->id. '">
                                </form>';
                            echo '<br><br>';
                            $_SESSION['username_clanak_postoji'] = 1;
                        }
                    }
                    if (!isset($_SESSION['username_clanak_postoji']))
                    {
                        echo '<p class="obavijest2_pregled_vijesti">
                        Niste unijeli niti jednu vijest !';
                        unset($_SESSION['username_clanak_postoji']);
                    }
                }
                else 
                {
                    echo '<p class="obavijest_pregled_vijesti">
                    Morate biti prijavljeni da bi mogli vidjeti svoje vijesti !</p>';
                }
            ?>
        </div>
    </main>
    <footer>
        <div id="center">
            <p>Stranicu napravio: Matija Đurekovec</p>
            <p>E-mail: mdurekove@tvz.hr</p>
            <b><p>Copyright © 2021 BMK.</p></b>
        </div>
    </footer>
</body>
</html>