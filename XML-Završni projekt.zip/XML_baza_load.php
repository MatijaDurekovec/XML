<?php

    $vijestiXML = simplexml_load_file("vijesti.xml");
    $korisniciXML = simplexml_load_file("korisnici.xml");

?>