<?php

    session_start();
    include 'XML_baza_load.php';
    setlocale(LC_ALL,'croatian'); 
    $datum = ucwords (iconv('ISO-8859-2', 'UTF-8',strftime('%A, %d %B')));
    
?>

<!DOCTYPE html>
<html>
<head>
    <title>BMK</title>
    <meta charset="UTF-8"/>
    <meta name="author" content="Matija Đurekovec"/>
    <meta http-equiv="content-language" content="hr"/>
    <link rel="stylesheet" type="text/css" href="style.css"/>
    <link rel="icon" href="img/bmk-logo-fav.png" type="image/x-icon">
</head>
<body>
    <header>
        <div id="center">
            <nav>
                <ul>
                    <li><a href="index.php"><img src="img/bmk-logo.png"></a></li>
                    <li class="lista_polozaj"><a href="index.php">Početna</a></li>
                    <li class="lista_polozaj"><a href="vijesti.php">Vijesti</a></li>
                    <li class="lista_polozaj"><a href="unos.php">Unos vijesti</a></li>
                    <li class="lista_polozaj"><a href="administracija.php">Pregled vijesti</a></li>
                    <li class="lista_polozaj"><a href="about.php">O nama</a></li>
                </ul>
                <ul id="prijava_registracija">
                    <?php
                        if (isset($_COOKIE['username']))
                        {
                            echo '
                                <li><a href="">' .$_COOKIE['username']. '</a></li>
                                <li><a href="logout.php">Odjava</a></li>
                            ';
                        }
                        else
                        {
                            echo '
                                <li><a href="login.php">Prijava</a></li>
                                <li><a href="register.php">Registracija</a></li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <main id="register">
        <div id="center">
            <?php
                if (isset($_SESSION['isti_email']))
                {
                    echo '<p class="registracija_error">';
                    echo '<b>Uneseni e-mail se već koristi !</b>';
                    echo '<br><br></p>';
                    unset($_SESSION['isti_email']);
                }
                if (isset($_SESSION['isti_user']))
                {
                    echo '<p class="registracija_user_error">';
                    echo '<b>Uneseno korisničko ime se već koristi !</b>';
                    echo '<br><br></p>';
                    unset($_SESSION['isti_user']);
                }
                if (isset($_SESSION['registracija']))
                {
                    echo '<p class="registracija_tekst">';
                    echo "Uspješna registracija !";
                    echo "<br>Dobro došli <b>" .$_SESSION['ime']. "</b> !</p>";
                    unset($_SESSION['registracija']);
                    unset($_SESSION['ime']);
                }
                else
                {
                    echo '
                        <form method="POST">
                            <label for="ime">Ime</label><br>
                            <input type="text" name="ime" autofocus required><br><br>
                            <label for="prezime">Prezime</label><br>
                            <input type="text" name="prezime" required><br><br>
                            <label for="username">Username</label><br>
                            <input type="text" name="username" required><br><br>
                            <label for="e-mail">E-mail</label><br>
                            <input type="email" name="e-mail" required><br><br>
                            <label for="sifra">Lozinka</label><br>
                            <input type="password" name="sifra" required><br><br>
                            <input type="submit" value="Registracija" id="reset_submit">
                            <input type="reset" value="Poništi" id="reset_submit">
                        </form>
                    ';
                }
            ?>
        </div>
    </main>
    <footer>
        <div id="center">
            <p>Stranicu napravio: Matija Đurekovec</p>
            <p>E-mail: mdurekove@tvz.hr</p>
            <b><p>Copyright © 2021 BMK.</p></b>
        </div>
    </footer>
</body>
</html>

<?php

if (isset($_POST['ime']))
{
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $username = $_POST['username'];
    $e_mail = $_POST['e-mail'];
    $sifra = $_POST['sifra'];

    // PROVJERA DA LI POSTOJI ISTI E-MAIL ILI USERNAME U XML BAZI //
    
    foreach ($korisniciXML->Korisnik as $provjera)
    {
        if ($provjera->email_korisnika == $e_mail)
        {
            $_SESSION['isti_email'] = 1;
            header("Location:register.php");
        }
        if ($provjera->username_korisnika == $username)
        {
            $_SESSION['isti_user'] = 1;
            header("Location:register.php");
        }
    }

    
    if (!isset($_SESSION['isti_email']) && !isset($_SESSION['isti_user']))
    {

        foreach ($korisniciXML->Korisnik as $broj)
        {
            $id = $broj->id; 
        }

        $id = $id + 1;

        // UNOS ZA XML BAZU //

        $XML_root = 'Korisnici';

        $unos = new DOMDocument ('1.0' , 'UTF-8');
        $unos->preserveWhiteSpace = true;
        $unos->standalone = true;
        $unos->formatOutput = true;
        $unos->recover = true;
        $unos->strictErrorChecking = true;

        // PROVJERA DA LI POSTOJI DATOTEKA //

        if (realpath ('korisnici.xml'))
        {
            $unos->load('korisnici.xml');
            $root = $unos->getElementsByTagName($XML_root)->item(0);
        }

        // KREIRANJE ELEMENATA //

        $kreiranje_korisnika = $unos->createElement('Korisnik');
        $root->appendChild($kreiranje_korisnika);

        $kreiranje_korisnika_id = $unos->createElement('id',$id);
        $kreiranje_korisnika->appendChild($kreiranje_korisnika_id);

        $kreiranje_korisnika_ime = $unos->createElement('ime_korisnika',$ime);
        $kreiranje_korisnika->appendChild($kreiranje_korisnika_ime);

        $kreiranje_korisnika_prezime = $unos->createElement('prezime_korisnika',$prezime);
        $kreiranje_korisnika->appendChild($kreiranje_korisnika_prezime);

        $kreiranje_korisnika_email = $unos->createElement('email_korisnika',$e_mail);
        $kreiranje_korisnika->appendChild($kreiranje_korisnika_email);

        $kreiranje_korisnika_username = $unos->createElement('username_korisnika',$username);
        $kreiranje_korisnika->appendChild($kreiranje_korisnika_username);

        $kreiranje_korisnika_sifra = $unos->createElement('sifra_korisnika',$sifra);
        $kreiranje_korisnika->appendChild($kreiranje_korisnika_sifra);

        // AŽURIRANJE NOVOG DOKUMENTA //

        $unos->save('korisnici.xml');

        if ($unos)
        {
            $_SESSION['registracija'] = 1;
            $_SESSION['ime'] = $ime;
            header("Location:register.php");
        }
        else 
        {
            echo "Registracija neuspješna :(";
        }

    }

    
}

?>