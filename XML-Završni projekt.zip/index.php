<?php
    include 'XML_baza_load.php';
    session_start();
    setlocale(LC_ALL,'croatian'); 
    $datum = ucwords (iconv('ISO-8859-2', 'UTF-8',strftime('%A, %d %B')));
    $brojac = 0;
    $ESP = 'E-sports';
    
?>

<!DOCTYPE html>
<html>
<head>
    <title>BMK</title>
    <meta charset="UTF-8"/>
    <meta name="author" content="Matija Đurekovec"/>
    <meta http-equiv="content-language" content="hr"/>
    <link rel="stylesheet" type="text/css" href="style.css"/>
    <link rel="icon" href="img/bmk-logo-fav.png" type="image/x-icon">
</head>
<body>
    <header>
        <div id="center">
            <nav>
                <ul>
                    <li><a href="index.php"><img src="img/bmk-logo.png"></a></li>
                    <li class="lista_polozaj"><a href="index.php">Početna</a></li>
                    <li class="lista_polozaj"><a href="vijesti.php">Vijesti</a></li>
                    <li class="lista_polozaj"><a href="unos.php">Unos vijesti</a></li>
                    <li class="lista_polozaj"><a href="administracija.php">Pregled vijesti</a></li>
                    <li class="lista_polozaj"><a href="about.php">O nama</a></li>
                </ul>
                <ul id="prijava_registracija">
                    <?php
                        if (isset($_COOKIE['username']))
                        {
                            echo '
                                <li><a href="">' .$_COOKIE['username']. '</a></li>
                                <li><a href="logout.php">Odjava</a></li>
                            ';
                        }
                        else
                        {
                            echo '
                                <li><a href="login.php">Prijava</a></li>
                                <li><a href="register.php">Registracija</a></li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <main>
        <div id="center">
            <h2 id="welcome">Dobro došli na BMK stranicu !</h2>
            <h2 id="datum">
                <?php
                    echo $datum;
                ?>
            </h2>
            <section class="section_index">
                <h2><img class="blue-bar" src="img/blue-bar.png">GAMING</h2>
                    <?php

                        // XML BAZA //
                        foreach ($vijestiXML->Gaming as $gaming_vijesti)
                        {
                            $vijesti_id = $gaming_vijesti->id;
                            $vijesti_naslov = $gaming_vijesti->naslov;
                            $vijesti_kratki_sadrzaj = $gaming_vijesti->kratki_sadrzaj;
                            $vijesti_slika = $gaming_vijesti->slika;
                            $vijesti_arhiva = $gaming_vijesti->arhiva;

                            if ($brojac < 3 && $vijesti_arhiva == 'N')
                            {
                                echo '<article>';
                                echo '<a href="clanak.php?id=' .$vijesti_id. '&kategorija=Gaming">';
                                echo '<img src="img/' .$vijesti_slika.   '">';
                                echo '<h3>' .$vijesti_naslov. '</h3></a>';
                                echo '<p>' .$vijesti_kratki_sadrzaj. '</p>';
                                echo '</article>';
                                $brojac++;
                            }
                        }
                        
                    ?>
            </section>
            <section class="section_index">
                <h2><img class="green-bar" src="img/green-bar.png">E-SPORTS</h2>
                    <?php

                         // XML BAZA //
                         $brojac = 0;
                         foreach ($vijestiXML->$ESP as $esports_vijesti)
                         {
                             $vijesti_id = $esports_vijesti->id;
                             $vijesti_naslov = $esports_vijesti->naslov;
                             $vijesti_kratki_sadrzaj = $esports_vijesti->kratki_sadrzaj;
                             $vijesti_slika = $esports_vijesti->slika;
                             $vijesti_arhiva = $esports_vijesti->arhiva;
 
                             if ($brojac < 3 && $vijesti_arhiva == 'N')
                             {
                                 echo '<article>';
                                 echo '<a href="clanak.php?id=' .$vijesti_id. '&kategorija=E-sports">';
                                 echo '<img src="img/' .$vijesti_slika.   '">';
                                 echo '<h3>' .$vijesti_naslov. '</h3></a>';
                                 echo '<p>' .$vijesti_kratki_sadrzaj. '</p>';
                                 echo '</article>';
                                 $brojac++;
                             }
                         }
                    ?>
            </section>
            <section class="section_index">
                <h2><img class="yellow-bar" src="img/yellow-bar.png">TEHNOLOGIJA</h2>
                    <?php

                         // XML BAZA //
                         $brojac = 0;
                         foreach ($vijestiXML->Tehnologija as $tehnologija_vijesti)
                         {
                             $vijesti_id = $tehnologija_vijesti->id;
                             $vijesti_naslov = $tehnologija_vijesti->naslov;
                             $vijesti_kratki_sadrzaj = $tehnologija_vijesti->kratki_sadrzaj;
                             $vijesti_slika = $tehnologija_vijesti->slika;
                             $vijesti_arhiva = $tehnologija_vijesti->arhiva;
 
                             if ($brojac < 3 && $vijesti_arhiva == 'N')
                             {
                                 echo '<article>';
                                 echo '<a href="clanak.php?id=' .$vijesti_id. '&kategorija=Tehnologija">';
                                 echo '<img src="img/' .$vijesti_slika.   '">';
                                 echo '<h3>' .$vijesti_naslov. '</h3></a>';
                                 echo '<p>' .$vijesti_kratki_sadrzaj. '</p>';
                                 echo '</article>';
                                 $brojac++;
                             }
                         }
                    ?>
            </section>
            <section class="section_index">
                <h2><img class="red-bar" src="img/red-bar.png">YOUTUBE</h2>
                    <?php

                         // XML BAZA //
                         $brojac = 0;
                         foreach ($vijestiXML->YouTube as $youtube_vijesti)
                         {
                             $vijesti_id = $youtube_vijesti->id;
                             $vijesti_naslov = $youtube_vijesti->naslov;
                             $vijesti_kratki_sadrzaj = $youtube_vijesti->kratki_sadrzaj;
                             $vijesti_slika = $youtube_vijesti->slika;
                             $vijesti_arhiva = $youtube_vijesti->arhiva;
 
                             if ($brojac < 3 && $vijesti_arhiva == 'N')
                             {
                                 echo '<article>';
                                 echo '<a href="clanak.php?id=' .$vijesti_id. '&kategorija=YouTube">';
                                 echo '<img src="img/' .$vijesti_slika.   '">';
                                 echo '<h3>' .$vijesti_naslov. '</h3></a>';
                                 echo '<p>' .$vijesti_kratki_sadrzaj. '</p>';
                                 echo '</article>';
                                 $brojac++;
                             }
                         }
                    ?>
            </section>
        </div>
    </main>
    <footer>
        <div id="center">
            <p>Stranicu napravio: Matija Đurekovec</p>
            <p>E-mail: mdurekove@tvz.hr</p>
            <b><p>Copyright © 2021 BMK.</p></b>
        </div>
    </footer>
</body>
</html>
