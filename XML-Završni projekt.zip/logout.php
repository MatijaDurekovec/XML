<?php

setcookie('id','',time() - 1080);
setcookie('username','',time() - 1080);
header("Location:index.php");

?>